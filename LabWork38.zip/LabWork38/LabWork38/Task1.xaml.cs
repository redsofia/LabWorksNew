﻿using System.Data;
using System.IO;
using System.Windows;

namespace LabWork38
{
    /// <summary>
    /// Interaction logic for Task1.xaml
    /// </summary>
    public partial class Task1 : Window
    {
        public int PageSize { get; set; } = 5;
        public int CurrentPage { get; set; } = 1;
        public int PagesCount => (int)Math.Ceiling((double)allFiles.Length / PageSize);
        private FileInfo[] allFiles;

        public Task1()
        {
            InitializeComponent();
            LoadFiles();
            ShowFiles();
        }

        private void LoadFiles()
        {
            var path = "D:\\Личное\\Софья";
            var directory = new DirectoryInfo(path);
            allFiles = directory.GetFiles()
                .OrderBy(f => f.Name)
                .ToArray();
        }

        private void ShowFiles()
        {
            var filesToShow = allFiles
                .Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .Select(f => new
                {
                    Name = f.Name,
                    Size = (f.Length / 1024.0).ToString("F2") + "KB",
                    Created = f.CreationTime

                });

            FilesListView.ItemsSource = filesToShow;
            UpdateStatus();
            ShowMoreButton.IsEnabled = CurrentPage < PagesCount;
        }

        private void UpdateStatus()
        {
            int shownFiles = Math.Min(PageSize, allFiles.Length - (CurrentPage - 1) * PageSize);
            StatusTextBlock.Text = $"Показано {(CurrentPage - 1) * PageSize + shownFiles} из {allFiles.Length} записей. Всего страниц: {PagesCount}";
        }

        private void ShowMoreButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage < PagesCount)
            {
                CurrentPage++;
                ShowFiles();
            }
        }
    }
}