﻿using System.IO;
using System.Windows;
using System.Windows.Input;

namespace LabWork38
{
    /// <summary>
    /// Логика взаимодействия для Task2.xaml
    /// </summary>
    public partial class Task2 : Window
    {
        public int PageSize { get; set; } = 5;
        public int CurrentPage
        {
            get => _currentPage;
            set
            {
                _currentPage = value;
                PageNumberTextBox.Text = value.ToString();
                UpDateNavigation();
                ShowFiles();
            }
        }

        public int _currentPage = 1;
        public int PagesCount => (int)Math.Ceiling((double)filteredFiles.Count / PageSize);
        private FileInfo[] allFiles;
        private List<FileInfo> filteredFiles;

        public Task2()
        {
            InitializeComponent();
            LoadFiles();
            CurrentPage = 1;
        }

        private void LoadFiles()
        {
            var path = "D:\\Личное\\Софья";
            var directory = new DirectoryInfo(path);
            allFiles = directory.GetFiles()
                .OrderBy(f => f.Name)
                .ToArray();
            filteredFiles = allFiles.ToList();
        }

        private void ShowFiles()
        {
            if (filteredFiles == null || filteredFiles.Count == 0)
            {
                FilesListView.ItemsSource = null;
                return;
            }

            var filesToShow = filteredFiles
                .Skip((CurrentPage - 1) * PageSize)
                .Take(PageSize)
                .Select(f => new
                {
                    Name = f.Name,
                    Size = (f.Length / 1024.0).ToString("F2") + "KB",
                    Created = f.CreationTime
                });

            FilesListView.ItemsSource = filesToShow;
        }

        private void UpDateNavigation()
        {
            FirstPageButton.IsEnabled = CurrentPage > 1;
            PrevPageButton.IsEnabled = CurrentPage > 1;
            NextPageButton.IsEnabled = CurrentPage < PagesCount;
            LastPageButton.IsEnabled = CurrentPage < PagesCount;
            PageInfoText.Text = $"Показано {CurrentPage} из {PagesCount} страниц";
        }

        private void FirstPageButton_Click(object sender, RoutedEventArgs e)
        {
            CurrentPage = 1;
            ShowFiles();
        }

        private void PrevPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage > 1)
            {
                CurrentPage--;
                ShowFiles();
            }
        }

        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (CurrentPage < PagesCount)
            {
                CurrentPage++;
                ShowFiles();
            }
        }

        private void LastPageButton_Click(object sender, RoutedEventArgs e)
        {
            CurrentPage = PagesCount;
            ShowFiles();
        }

        private void PageNumberTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (int.TryParse(PageNumberTextBox.Text, out int pageNumber))
                {
                    if (pageNumber >= 1 && pageNumber <= PagesCount)
                    {
                        CurrentPage = pageNumber;
                        ShowFiles();
                    }
                    else
                    {
                        MessageBox.Show($"Введите номер страницы от 1 до {PagesCount}");
                    }
                }
                else
                {
                    MessageBox.Show("Введите корректный номер страницы");
                }
            }
        }

        private void FilterBox_TextCanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            var filter = FilterBox.Text.ToLower();
            filteredFiles = allFiles
                .Where(f => f.Name.ToLower().Contains(filter))
                .ToList();
            CurrentPage = 1;
            UpDateNavigation();
            ShowFiles();
        }
    }
}
