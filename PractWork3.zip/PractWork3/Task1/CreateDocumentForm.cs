﻿using Microsoft.Office.Interop.Word;
using Word = Microsoft.Office.Interop.Word;

namespace Task1
{
    public partial class CreateDocumentForm : Form
    {
        public CreateDocumentForm()
        {
            InitializeComponent();
        }

        private void CreateDocumentButton_Click(object sender, EventArgs e)
        {
            var inputText = InputRichTextBox.Text;
            int numTasks = (int)LinesNumericUpDown.Value;

            var wordApp = new Word.Application();
            wordApp.Visible = true;

            string templatePath = Environment.CurrentDirectory + "\\Шаблон.docx";
            Word.Document doc = wordApp.Documents.Open(templatePath);

            doc.Content.Find.Execute(FindText: "ТекстИзПоляВвода", ReplaceWith: inputText, Replace: Word.WdReplace.wdReplaceAll);
            doc.Content.Find.Execute(FindText: "дд.мм.гггг чч:мм", ReplaceWith: DateTime.Now.ToString(), Replace: Word.WdReplace.wdReplaceAll);

            EditTaskTable(doc, numTasks);
            AddTaskTable(doc, numTasks);

            using SaveFileDialog dialog = new();
            SaveFileDialog.Filter = "Word (*.docx)|*.docx|PDF (*.pdf)|*.pdf";
            SaveFileDialog.Title = "Сохранить как";

            if (SaveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string fileSave = SaveFileDialog.FileName;
                if (fileSave.EndsWith(".pdf"))
                    doc.SaveAs2(fileSave, WdSaveFormat.wdFormatPDF);
                else
                    doc.SaveAs2(fileSave, WdSaveFormat.wdFormatXMLDocument);
                MessageBox.Show("Документ успешно сохранен.", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void EditTaskTable(Word.Document doc, int numTasks)
        {
            Table table = doc.Tables[1];
            var range = table.Cell(2, 1).Range;
            range.Text = 1.ToString();
            for (int i = 1; i < numTasks; i++)
            {
                Row row = table.Rows.Add();
                row.Cells[1].Range.Text = (i + 1).ToString();
            }
        }
        private void AddTaskTable(Word.Document doc, int numTasks)
        {
            var para0 = doc.Paragraphs.Add();
            var para = doc.Paragraphs.Add();
            para.Range.Text = "Таблица 1 — Задания";
            para.Range.InsertParagraphAfter();

            Table taskTable = doc.Tables.Add(para.Range, numTasks + 1, 2);
            taskTable.Borders.InsideLineStyle = taskTable.Borders.OutsideLineStyle = Word.WdLineStyle.wdLineStyleSingle;

            taskTable.Cell(1, 1).Range.Text = "Номер задания";
            taskTable.Cell(1, 2).Range.Text = "Описание задания";

            for (int i = 0; i < numTasks; i++)
            {
                taskTable.Cell(i + 2, 1).Range.Text = (i + 1).ToString();
                taskTable.Cell(i + 2, 2).Range.Text = "Описание задания " + (i + 1);
            }
        }
    }
}

