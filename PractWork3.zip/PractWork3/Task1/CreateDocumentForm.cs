﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace Task1
{
    public partial class CreateDocumentForm : Form
    {
        public CreateDocumentForm()
        {
            InitializeComponent();
        }

        private void CreateDocumentButton_Click(object sender, EventArgs e)
        {
            string templatePath = "Шаблон.docx";
            string outputPath = "Документ.docx";

            var wordApp = new Word.Application();
            var doc = wordApp.Documents.Open(templatePath);

            doc.Content.Text = InputRichTextBox.Text;
            ReplaceText(doc, "<Дата и время>", DateTime.Now.ToString());

            // Добавление строк в таблицу
            int numTasks = (int)LinesNumericUpDown.Value;
            AddRowsToTable(doc, numTasks);

            // Сохранение и отображение документа
            doc.SaveAs2(outputPath);
            doc.Activate();
            wordApp.Visible = true;
        }

        private void ReplaceText(Word.Document doc, string placeholder, string replacement)
        {
            doc.Content.Find.Execute(FindText: placeholder, ReplaceWith: replacement);
        }

        private void AddRowsToTable(Word.Document doc, int numTasks)
        {
            Word.Table table = doc.Tables[1];
            for (int i = 0; i < numTasks; i++)
            {
                table.Rows.Add();
            }
        }
    }
}

