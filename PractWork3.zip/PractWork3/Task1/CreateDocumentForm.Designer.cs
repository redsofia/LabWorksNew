﻿namespace Task1
{
    partial class CreateDocumentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            CreateDocumentButton = new Button();
            InputRichTextBox = new RichTextBox();
            LinesNumericUpDown = new NumericUpDown();
            TextLabel = new Label();
            LinesLabel = new Label();
            SaveFileDialog = new SaveFileDialog();
            ((System.ComponentModel.ISupportInitialize)LinesNumericUpDown).BeginInit();
            SuspendLayout();
            // 
            // CreateDocumentButton
            // 
            CreateDocumentButton.Location = new Point(349, 242);
            CreateDocumentButton.Name = "CreateDocumentButton";
            CreateDocumentButton.Size = new Size(194, 23);
            CreateDocumentButton.TabIndex = 0;
            CreateDocumentButton.Text = "Создать документ по шабону";
            CreateDocumentButton.UseVisualStyleBackColor = true;
            CreateDocumentButton.Click += CreateDocumentButton_Click;
            // 
            // InputRichTextBox
            // 
            InputRichTextBox.Location = new Point(52, 72);
            InputRichTextBox.Name = "InputRichTextBox";
            InputRichTextBox.Size = new Size(390, 128);
            InputRichTextBox.TabIndex = 1;
            InputRichTextBox.Text = "";
            // 
            // LinesNumericUpDown
            // 
            LinesNumericUpDown.Location = new Point(52, 244);
            LinesNumericUpDown.Name = "LinesNumericUpDown";
            LinesNumericUpDown.Size = new Size(120, 23);
            LinesNumericUpDown.TabIndex = 2;
            // 
            // TextLabel
            // 
            TextLabel.AutoSize = true;
            TextLabel.Location = new Point(52, 41);
            TextLabel.Name = "TextLabel";
            TextLabel.Size = new Size(36, 15);
            TextLabel.TabIndex = 3;
            TextLabel.Text = "Текст";
            // 
            // LinesLabel
            // 
            LinesLabel.AutoSize = true;
            LinesLabel.Location = new Point(52, 226);
            LinesLabel.Name = "LinesLabel";
            LinesLabel.Size = new Size(106, 15);
            LinesLabel.TabIndex = 4;
            LinesLabel.Text = "Количество строк";
            // 
            // CreateDocumentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(595, 347);
            Controls.Add(LinesLabel);
            Controls.Add(TextLabel);
            Controls.Add(LinesNumericUpDown);
            Controls.Add(InputRichTextBox);
            Controls.Add(CreateDocumentButton);
            Name = "CreateDocumentForm";
            Text = "CreateDocumentForm";
            ((System.ComponentModel.ISupportInitialize)LinesNumericUpDown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button CreateDocumentButton;
        private RichTextBox InputRichTextBox;
        private NumericUpDown LinesNumericUpDown;
        private Label TextLabel;
        private Label LinesLabel;
        private SaveFileDialog SaveFileDialog;
    }
}