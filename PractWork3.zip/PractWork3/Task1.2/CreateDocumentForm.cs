﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;

namespace Task1._2
{
    public partial class CreateDocumentForm : Form
    {
        public CreateDocumentForm()
        {
            InitializeComponent();
        }

        private void CreateDocumentButton_Click(object sender, EventArgs e)
        {
            var wordApp = new Word.Application();
            wordApp.Visible = true;

            // Открытие шаблонного документа
            Document doc = wordApp.Documents.Open("Шаблон.docx");

            // Замена текста в документе
            doc.Content.Find.Text = "[TEXT_PLACEHOLDER]";
            doc.Content.Find.Replacement.Text = InputRichTextBox.Text;
            doc.Content.Find.Execute(Replace: WdReplace.wdReplaceAll);

            // Создание таблицы с указанным количеством строк
            int numTasks = (int)LinesNumericUpDown.Value;
            Table table = doc.Tables.Add(doc.Range(), numTasks + 1, 2);
            table.Borders.InsideLineStyle = WdLineStyle.wdLineStyleSingle;
            table.Borders.OutsideLineStyle = WdLineStyle.wdLineStyleSingle;

            // Заполнение таблицы
            for (int i = 1; i <= numTasks + 1; i++)
            {
                table.Cell(i, 1).Range.Text = "Задание " + i;
            }

            // Вставка даты и времени в конец документа
            Word.Range range = doc.Content;
            range.Collapse(WdCollapseDirection.wdCollapseEnd);
            range.InsertAfter(Environment.NewLine + "Дата и время создания: " + DateTime.Now.ToString());

            // Сохранение и открытие документа
            string newDocumentPath = "Новый документ.docx";
            doc.SaveAs2(newDocumentPath);
            doc.Close();
            wordApp.Visible = true;
            wordApp.Documents.Open(newDocumentPath);
        }
    }
}
