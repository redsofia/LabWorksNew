﻿namespace Task1._2
{
    partial class CreateDocumentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            LinesLabel = new Label();
            TextLabel = new Label();
            LinesNumericUpDown = new NumericUpDown();
            InputRichTextBox = new RichTextBox();
            CreateDocumentButton = new Button();
            ((System.ComponentModel.ISupportInitialize)LinesNumericUpDown).BeginInit();
            SuspendLayout();
            // 
            // LinesLabel
            // 
            LinesLabel.AutoSize = true;
            LinesLabel.Location = new Point(35, 208);
            LinesLabel.Name = "LinesLabel";
            LinesLabel.Size = new Size(106, 15);
            LinesLabel.TabIndex = 9;
            LinesLabel.Text = "Количество строк";
            // 
            // TextLabel
            // 
            TextLabel.AutoSize = true;
            TextLabel.Location = new Point(35, 23);
            TextLabel.Name = "TextLabel";
            TextLabel.Size = new Size(36, 15);
            TextLabel.TabIndex = 8;
            TextLabel.Text = "Текст";
            // 
            // LinesNumericUpDown
            // 
            LinesNumericUpDown.Location = new Point(35, 226);
            LinesNumericUpDown.Name = "LinesNumericUpDown";
            LinesNumericUpDown.Size = new Size(120, 23);
            LinesNumericUpDown.TabIndex = 7;
            // 
            // InputRichTextBox
            // 
            InputRichTextBox.Location = new Point(35, 54);
            InputRichTextBox.Name = "InputRichTextBox";
            InputRichTextBox.Size = new Size(390, 128);
            InputRichTextBox.TabIndex = 6;
            InputRichTextBox.Text = "";
            // 
            // CreateDocumentButton
            // 
            CreateDocumentButton.Location = new Point(332, 224);
            CreateDocumentButton.Name = "CreateDocumentButton";
            CreateDocumentButton.Size = new Size(194, 23);
            CreateDocumentButton.TabIndex = 5;
            CreateDocumentButton.Text = "Создать документ по шабону";
            CreateDocumentButton.UseVisualStyleBackColor = true;
            CreateDocumentButton.Click += CreateDocumentButton_Click;
            // 
            // CreateDocumentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(599, 334);
            Controls.Add(LinesLabel);
            Controls.Add(TextLabel);
            Controls.Add(LinesNumericUpDown);
            Controls.Add(InputRichTextBox);
            Controls.Add(CreateDocumentButton);
            Name = "CreateDocumentForm";
            Text = "CreateDocumentForm";
            ((System.ComponentModel.ISupportInitialize)LinesNumericUpDown).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label LinesLabel;
        private Label TextLabel;
        private NumericUpDown LinesNumericUpDown;
        private RichTextBox InputRichTextBox;
        private Button CreateDocumentButton;
    }
}