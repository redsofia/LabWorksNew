﻿using Word = Microsoft.Office.Interop.Word;

namespace Task2
{
    public partial class CreateDocumentForm : Form
    {
        public CreateDocumentForm()
        {
            InitializeComponent();
        }

        private void CreateDocumentButton_Click(object sender, EventArgs e)
        {
            var wordApp = new Word.Application();
            wordApp.Visible = true;
            var doc = wordApp.Documents.Add();

            doc.Content.Text = TextRichTextBox.Text;

            doc.Content.Font.Name = "Times New Roman";
            doc.Paragraphs.Alignment = Word.WdParagraphAlignment.wdAlignParagraphJustify;
            doc.Content.Font.Size = 14;
        }
    }
}
