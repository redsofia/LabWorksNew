﻿namespace Task2
{
    partial class CreateDocumentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TextLabel = new Label();
            CreateDocumentButton = new Button();
            TextRichTextBox = new RichTextBox();
            SuspendLayout();
            // 
            // TextLabel
            // 
            TextLabel.AutoSize = true;
            TextLabel.Location = new Point(33, 25);
            TextLabel.Name = "TextLabel";
            TextLabel.Size = new Size(36, 15);
            TextLabel.TabIndex = 5;
            TextLabel.Text = "Текст";
            // 
            // CreateDocumentButton
            // 
            CreateDocumentButton.Location = new Point(310, 231);
            CreateDocumentButton.Name = "CreateDocumentButton";
            CreateDocumentButton.Size = new Size(137, 23);
            CreateDocumentButton.TabIndex = 4;
            CreateDocumentButton.Text = "Создать документ";
            CreateDocumentButton.UseVisualStyleBackColor = true;
            CreateDocumentButton.Click += CreateDocumentButton_Click;
            // 
            // TextRichTextBox
            // 
            TextRichTextBox.Location = new Point(33, 53);
            TextRichTextBox.Name = "TextRichTextBox";
            TextRichTextBox.Size = new Size(359, 155);
            TextRichTextBox.TabIndex = 3;
            TextRichTextBox.Text = "";
            // 
            // CreateDocumentForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(542, 307);
            Controls.Add(TextLabel);
            Controls.Add(CreateDocumentButton);
            Controls.Add(TextRichTextBox);
            Name = "CreateDocumentForm";
            Text = "CreateDocumentForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label TextLabel;
        private Button CreateDocumentButton;
        private RichTextBox TextRichTextBox;
    }
}