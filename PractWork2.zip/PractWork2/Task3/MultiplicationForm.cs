﻿using Excel = Microsoft.Office.Interop.Excel;

namespace Task3
{
    public partial class MultiplicationForm : Form
    {
        public MultiplicationForm()
        {
            InitializeComponent();
        }

        private void MultiplicationButton_Click(object sender, EventArgs e)
        {
            // новый экземпляр Excel
            var excelApp = new Excel.Application();
            excelApp.Visible = true;

            // новая книга
            var workbook = excelApp.Workbooks.Add();
            var worksheet = (Excel.Worksheet)workbook.Worksheets[1];
            worksheet.Name = "Умножение";

            // заполнение
            for (int i = 2; i <= 9; i++)
                for (int j = 2; j <= 9; j++)
                    worksheet.Cells[i - 1, j - 1] = i * j; // ячейка результата

            // заголовки
            worksheet.Cells[1, 1] = ""; // Пустая ячейка
            for (int i = 2; i <= 9; i++)
            {
                worksheet.Cells[1, i - 1] = i; // столбцы
                worksheet.Cells[i - 1, 1] = i; // строки
            }

            //форматирование
            worksheet.Range["D10:K17"].Value = worksheet.Range["A1:H8"].Value; // перемещение таблицы
            worksheet.Range["A1:H8"].Value = "";
            worksheet.Range["D9:K9"].Merge();
            worksheet.Range["D9"].Value = "Таблица умножения";
            worksheet.Range["D9"].Font.Bold = true; // полужирный
            worksheet.Range["D9"].Font.Italic = true; // курсив
            worksheet.Range["D9"].Font.Size = 20; // размер шрифта
            worksheet.Range["D10:K17"].Font.Size = 15;
            worksheet.Range["D9"].HorizontalAlignment = Excel.XlHAlign.xlHAlignCenter; // выравнивание по центру

            worksheet.Range["E10:K10"].Interior.Color = ColorTranslator.ToOle(Color.Pink);
            worksheet.Range["D11:D17"].Interior.Color = ColorTranslator.ToOle(Color.PeachPuff);
            worksheet.Range["D10:K17"].BorderAround2();
            worksheet.Range["E10:K10"].BorderAround2();
            worksheet.Range["D11:D17"].BorderAround2();
        }
    }
}


