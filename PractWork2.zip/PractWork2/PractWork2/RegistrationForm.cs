﻿namespace Task1
{
    public partial class RegistrationForm : Form
    {
        private string filePath = "logins.csv";
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {
            string userLogin = LoginTextBox.Text.Trim();
            string userPassword = PasswordTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(userLogin) || string.IsNullOrWhiteSpace(userPassword))
            {
                MessageBox.Show("Логин и пароль не могут быть пустыми.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (IsLoginExists(userLogin))
            {
                MessageBox.Show("Логин уже существует. Пожалуйста, введите другой логин.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            RegisterUser(userLogin, userPassword);
            MessageBox.Show("Вы успешно зарегистрированы!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private bool IsLoginExists(string userLogin)
        {
            if (File.Exists(filePath))
            {
                var lines = File.ReadAllLines(filePath);
                return lines.Any(line => line.Split(';')[0].Equals(userLogin, StringComparison.OrdinalIgnoreCase));
            }
            return false;
        }

        private void RegisterUser(string userLogin, string userPassword)
        {
            string registrationDate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
            string newUserRecord = $"{userLogin};{userPassword};{registrationDate}";

            using StreamWriter streamWriter = File.AppendText(filePath);
            streamWriter.WriteLine(newUserRecord);
        }
    }
}
