﻿namespace Task1
{
    partial class RegistrationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            RegisterButton = new Button();
            LoginLabel = new Label();
            PasswordLabel = new Label();
            LoginTextBox = new TextBox();
            PasswordTextBox = new TextBox();
            SuspendLayout();
            // 
            // RegisterButton
            // 
            RegisterButton.Font = new Font("Segoe UI", 12F);
            RegisterButton.Location = new Point(279, 175);
            RegisterButton.Name = "RegisterButton";
            RegisterButton.Size = new Size(175, 33);
            RegisterButton.TabIndex = 0;
            RegisterButton.Text = "Зарегестрироватьтся";
            RegisterButton.UseVisualStyleBackColor = true;
            RegisterButton.Click += RegisterButton_Click;
            // 
            // LoginLabel
            // 
            LoginLabel.AutoSize = true;
            LoginLabel.Font = new Font("Segoe UI", 12F);
            LoginLabel.Location = new Point(22, 46);
            LoginLabel.Name = "LoginLabel";
            LoginLabel.Size = new Size(54, 21);
            LoginLabel.TabIndex = 1;
            LoginLabel.Text = "Логин";
            // 
            // PasswordLabel
            // 
            PasswordLabel.AutoSize = true;
            PasswordLabel.Font = new Font("Segoe UI", 12F);
            PasswordLabel.Location = new Point(22, 110);
            PasswordLabel.Name = "PasswordLabel";
            PasswordLabel.Size = new Size(63, 21);
            PasswordLabel.TabIndex = 2;
            PasswordLabel.Text = "Пароль";
            // 
            // LoginTextBox
            // 
            LoginTextBox.Location = new Point(96, 38);
            LoginTextBox.Name = "LoginTextBox";
            LoginTextBox.Size = new Size(280, 23);
            LoginTextBox.TabIndex = 3;
            // 
            // PasswordTextBox
            // 
            PasswordTextBox.Location = new Point(96, 102);
            PasswordTextBox.Name = "PasswordTextBox";
            PasswordTextBox.Size = new Size(280, 23);
            PasswordTextBox.TabIndex = 4;
            // 
            // RegistrationForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(558, 307);
            Controls.Add(PasswordTextBox);
            Controls.Add(LoginTextBox);
            Controls.Add(PasswordLabel);
            Controls.Add(LoginLabel);
            Controls.Add(RegisterButton);
            Name = "RegistrationForm";
            Text = "RegistrationForm";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button RegisterButton;
        private Label LoginLabel;
        private Label PasswordLabel;
        private TextBox LoginTextBox;
        private TextBox PasswordTextBox;
    }
}