﻿using Microsoft.Office.Interop.Excel;
class Program
{
    static void Main()
    {
        Console.WriteLine("Введите путь к каталогу:");
        string directoryPath = Console.ReadLine();

        if (!Directory.Exists(directoryPath))
        {
            Console.WriteLine("Указанный каталог не существует.");
            return;
        }

        // новый экземпляр Excel
        var excelApp = new Application();
        var workbook = excelApp.Workbooks.Add();
        var filesSheet = (Worksheet)workbook.Sheets[1];
        var subfoldersSheet = (Worksheet)workbook.Sheets.Add(After: filesSheet);

        // листы
        filesSheet.Name = "Файлы";
        subfoldersSheet.Name = "Подпапки";

        // заголовки первого листа
        filesSheet.Cells[1, 1] = "Номер файла";
        filesSheet.Cells[1, 2] = "Имя файла";
        filesSheet.Cells[1, 3] = "Размер файла (Б)";

        // заголовки второго листа
        subfoldersSheet.Cells[1, 1] = "Номер подпапки";
        subfoldersSheet.Cells[1, 2] = "Имя подпапки";

        // заполнение первого листа(файлы)
        var files = Directory.GetFiles(directoryPath);
        for (int i = 0; i < files.Length; i++)
        {
            var fileInfo = new FileInfo(files[i]);
            filesSheet.Cells[i + 2, 1] = i + 1; // номер файла
            filesSheet.Cells[i + 2, 2] = fileInfo.Name; // имя файла
            filesSheet.Cells[i + 2, 3] = fileInfo.Length; // размер файла
        }

        // заполнение второго листа(подпапки)
        var directories = Directory.GetDirectories(directoryPath);
        for (int i = 0; i < directories.Length; i++)
        {
            var dirInfo = new DirectoryInfo(directories[i]);
            subfoldersSheet.Cells[i + 2, 1] = i + 1; // номер подпапки
            subfoldersSheet.Cells[i + 2, 2] = dirInfo.Name; // имя подпапки
        }

        // сохранение
        string savePath = Path.Combine(directoryPath, "FilesAndSubfolders.xlsx");
        workbook.SaveAs(savePath);
        excelApp.Quit();

        Console.WriteLine($"Книга Excel сохранена по пути: {savePath}");
    }
}